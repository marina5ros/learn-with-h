Approved Learn with H Animal Farm Chapter 3 character portraits.
Place the six WebP images under english/animal-farm/assets/characters/ in feature/animal-farm-chapter-3.
Do not merge the draft PR until images and browser tests pass.
